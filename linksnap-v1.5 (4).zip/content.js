// LinkSnap content script
// Minimal — the heavy lifting happens in background.js via scripting.executeScript
// This file exists to satisfy manifest and for future enhancements
