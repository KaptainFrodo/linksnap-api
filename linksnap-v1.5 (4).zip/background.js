// LinkSnap — Background Service Worker v1.5
// Now uses ZBar (industry-standard decoder) instead of jsQR

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "linksnap-decode",
      title: "Open QR Link",
      contexts: ["image"]
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "linksnap-decode") return;
  const imageUrl = info.srcUrl;
  if (!imageUrl) { notifyTab(tab.id, "error", "Could not get image URL."); return; }

  // Fetch image bytes in service worker (bypasses CORS)
  let imageDataB64;
  try {
    const response = await fetch(imageUrl);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const buffer = await response.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = "";
    for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
    imageDataB64 = btoa(binary);
  } catch (e) {
    notifyTab(tab.id, "error", `Could not fetch image: ${e.message}`);
    return;
  }

  try {
    // Inject ZBar into the page
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["zbar.js"]
    });

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: decodeWithZBar,
      args: [imageDataB64]
    });

    const result = results?.[0]?.result;
    if (!result) { notifyTab(tab.id, "error", "Decoder returned no result."); return; }
    if (result.error) { notifyTab(tab.id, "error", result.error); return; }
    if (result.url) { chrome.tabs.create({ url: result.url }); }
    else if (result.text) { notifyTab(tab.id, "text", result.text); }

  } catch (e) {
    notifyTab(tab.id, "error", `Extension error: ${e.message}`);
  }
});

function notifyTab(tabId, type, message) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: showLinksnapToast,
    args: [type, message]
  }).catch(console.error);
}

// Runs in page context — uses ZBar WASM to decode
async function decodeWithZBar(b64) {
  try {
    // Build image from base64
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blobUrl = URL.createObjectURL(new Blob([bytes]));

    const img = await new Promise((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = reject;
      i.src = blobUrl;
    });
    URL.revokeObjectURL(blobUrl);

    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    if (!w || !h) return { error: "Image has no dimensions." };

    // Helper: draw image to canvas and get ImageData
    function toImageData(scaleOrCanvas) {
      const c = document.createElement("canvas");
      const scale = typeof scaleOrCanvas === "number" ? scaleOrCanvas : 1;
      c.width = Math.max(1, Math.round(w * scale));
      c.height = Math.max(1, Math.round(h * scale));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      return c.getContext("2d").getImageData(0, 0, c.width, c.height);
    }

    // Helper: pixel transform
    function transform(imageData, fn) {
      const d = new Uint8ClampedArray(imageData.data);
      for (let i = 0; i < d.length; i += 4) {
        const res = fn(d[i], d[i+1], d[i+2], d[i+3]);
        d[i]=res[0]; d[i+1]=res[1]; d[i+2]=res[2]; d[i+3]=res[3];
      }
      return new ImageData(d, imageData.width, imageData.height);
    }

    function toGray(id) {
      return transform(id, (r,g,b,a) => { const v=Math.round(0.299*r+0.587*g+0.114*b); return [v,v,v,a]; });
    }

    function stripColor(id, threshold) {
      return transform(id, (r,g,b,a) => {
        const mean=(r+g+b)/3, std=Math.sqrt(((r-mean)**2+(g-mean)**2+(b-mean)**2)/3);
        return std > threshold ? [255,255,255,a] : [r,g,b,a];
      });
    }

    function boostContrast(id, factor) {
      return transform(id, (r,g,b,a) => {
        const adj=v=>Math.max(0,Math.min(255,Math.round((v-128)*factor+128)));
        return [adj(r),adj(g),adj(b),a];
      });
    }

    // ZBar API: window.zbarWasm.scanImageData(imageData) → array of symbols
    const scan = async (imageData) => {
      if (!imageData || !imageData.width || !imageData.height) return null;
      try {
        const symbols = await window.zbarWasm.scanImageData(imageData);
        if (symbols && symbols.length > 0) return symbols[0].decode();
      } catch(e) {}
      return null;
    };

    // Passes — ZBar is much more capable than jsQR so we need fewer,
    // but still run a few preprocessings for edge cases
    const raw = toImageData(1);
    const passes = [
      () => scan(raw),                                    // 1. original (ZBar handles most cases natively)
      () => scan(toImageData(2)),                         // 2. 2x upscale (small QR codes)
      () => scan(toGray(raw)),                            // 3. grayscale
      () => scan(stripColor(raw, 20)),                    // 4. logo/watermark stripped
      () => scan(toGray(stripColor(raw, 20))),            // 5. logo stripped + grayscale
      () => scan(boostContrast(toGray(raw), 2.5)),        // 6. contrast boost
      () => scan(toGray(stripColor(toImageData(2), 20))), // 7. 2x + logo stripped
    ];

    for (const pass of passes) {
      try {
        const data = await pass();
        if (data) {
          const isUrl = /^https?:\/\//i.test(data) || /^www\./i.test(data);
          return isUrl ? { url: data.startsWith("http") ? data : "https://"+data } : { text: data };
        }
      } catch(e) { continue; }
    }

    return { error: "No QR code found. Make sure the QR code is fully visible and not too small." };

  } catch(e) {
    return { error: `Decode failed: ${e.message}` };
  }
}

function showLinksnapToast(type, message) {
  const existing = document.getElementById("__linksnap_toast");
  if (existing) existing.remove();
  if (!document.getElementById("__linksnap_styles")) {
    const s = document.createElement("style");
    s.id = "__linksnap_styles";
    s.textContent = `@keyframes __ls_in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}#__linksnap_toast{animation:__ls_in .2s ease}`;
    document.head.appendChild(s);
  }
  const colors = { error:"rgba(255,95,95,0.45)", text:"rgba(0,229,160,0.35)", info:"rgba(255,255,255,0.15)" };
  const labels = { error:"#ff5f5f", text:"#00e5a0", info:"#aaa" };
  const toast = document.createElement("div");
  toast.id = "__linksnap_toast";
  toast.style.cssText = `position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#16161a;border:1.5px solid ${colors[type]||colors.info};border-radius:12px;padding:14px 18px;font-family:monospace;font-size:13px;color:${labels[type]||labels.info};box-shadow:0 8px 32px rgba(0,0,0,0.6);max-width:360px;line-height:1.5;word-break:break-all`;
  if (type === "text") {
    const safe = message.replace(/</g,"&lt;").replace(/>/g,"&gt;");
    toast.innerHTML = `<div style="font-size:10px;letter-spacing:.1em;text-transform:uppercase;margin-bottom:8px;color:#00e5a0">// QR decoded — not a URL</div><div style="color:#f0efe8;margin-bottom:12px">${safe}</div><div style="display:flex;gap:8px"><button id="__ls_copy" style="flex:1;padding:7px;background:rgba(0,229,160,.15);border:1px solid rgba(0,229,160,.3);border-radius:7px;color:#00e5a0;font-size:11px;cursor:pointer;font-family:monospace">Copy</button><button id="__ls_close" style="padding:7px 12px;background:none;border:1px solid rgba(255,255,255,.1);border-radius:7px;color:#888;font-size:11px;cursor:pointer;font-family:monospace">✕</button></div>`;
    document.body.appendChild(toast);
    document.getElementById("__ls_copy").onclick = () => { navigator.clipboard.writeText(message); document.getElementById("__ls_copy").textContent="Copied!"; setTimeout(()=>toast.remove(),1500); };
    document.getElementById("__ls_close").onclick = () => toast.remove();
  } else {
    toast.textContent = (type==="error"?"❌ ":"ⓘ ") + message;
    document.body.appendChild(toast);
    setTimeout(() => toast?.remove(), 4000);
  }
}
